Add-Type -AssemblyName System.Drawing
Get-ChildItem -Recurse -Filter *.png | ForEach-Object {
    $img = [System.Drawing.Image]::FromFile($_.FullName)
    $relPath = $_.FullName.Substring("c:\Users\Pookie Boy\Documents\HAHA\Vehicles".Length + 1)
    Write-Output "$relPath : $($img.Width) x $($img.Height)"
    $img.Dispose()
}
